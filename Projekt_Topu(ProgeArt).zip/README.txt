Generatiivset kunsti loov programm.

Programmi saab käivitada faili programm.py käivitades, kus asub kasutajaliides, või programm.exe failist, mis asub exe kaustas.
Valmis pildid salvestatakse kausta "Valminud kunstiteosed".
Kui programm ei reageeri siis seda selle pärast, et mõne pildi joonistamisega läheb natuke kauem aega. 
Tasub proovida korduvalt ka ühe mustriga, sest juhuslikkuse tõttu võib meelepärasem disain tekkida alles mitmenda katsega.

Failis "kunst.py" on kunsti loovad funktsioonid, mis kasutavad põhinevad moodulil pycairo. 
Failis "lõuend.py" on mooduli pycairo vajalikud lõuendi (canvas) loomise käsud ja muud pildi salvestamise funktsioonid.
Kaustas "näidised" on kasutajaliidese kuvatavad näidispildid vastava funtksiooni, mille nimi peaks ühtima vastava funktsiooni nimega.
